export interface WalletProps {
    wallet?: string;
    connectWallet?: () => void;
  }
