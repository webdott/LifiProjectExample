import React from "react";

export interface LayoutProps {
  children: React.ReactNode;
}

export interface cardProps {
  data: string[];
}

export const cardData = ["#e6e6e6", "#33ffc1", "#505050"];
