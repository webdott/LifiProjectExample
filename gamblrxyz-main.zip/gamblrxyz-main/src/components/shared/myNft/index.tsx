import styles from "./myNft.module.scss";

export default function MyNft(): JSX.Element {
  return (
    <div className={styles.container}>
      <h1>My Nft</h1>
    </div>
  );
}
