import styles from "./settingsTab.module.scss";

export default function SettingsTab(): JSX.Element {
  return (
    <div className={styles.container}>
      <h1>Settings</h1>
    </div>
  );
}
