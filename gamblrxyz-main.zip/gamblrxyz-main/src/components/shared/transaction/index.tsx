import styles from "./transaction.module.scss";

export default function Transaction(): JSX.Element {
  return (
    <div className={styles.container}>
      <h1>Transaction</h1>
    </div>
  );
}
