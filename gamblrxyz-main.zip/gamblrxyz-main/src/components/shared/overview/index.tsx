import styles from "./overview.module.scss";

export default function Overview(): JSX.Element {
  return (
    <div className={styles.container}>
      <h1>Overview</h1>
    </div>
  );
}
