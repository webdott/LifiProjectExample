export interface MenuItemType {
  title: string;
}

export interface MenuType {
  menu: MenuItemType[];
  changeVisible: boolean;
}
